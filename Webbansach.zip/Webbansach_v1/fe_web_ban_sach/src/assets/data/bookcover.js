import Book1 from "../bookcover/book1.jpg";
import Book10 from "../bookcover/book10.jpg";
import Book2 from "../bookcover/book2.jpg";
import Book3 from "../bookcover/book3.jpg";
import Book4 from "../bookcover/book4.jpg";
import Book5 from "../bookcover/book5.jpg";
import Book6 from "../bookcover/book6.jpg";
import Book7 from "../bookcover/book7.jpg";
import Book8 from "../bookcover/book8.jpg";
import Book9 from "../bookcover/book9.jpg";
import BookCoverDefault from "../bookcover/bookCoverDefault.jpg";

export const bookCoverData = {
    book1: Book1,
    book2: Book2,
    book3: Book3,
    book4: Book4,
    book5: Book5,
    book6: Book6,
    book7: Book7,
    book8: Book8,
    book9: Book9,
    book10: Book10,
    null: BookCoverDefault,
};
