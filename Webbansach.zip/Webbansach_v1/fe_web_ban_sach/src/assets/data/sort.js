export const sortData = [
    {
        title: "Sort by on sale"
    },
    {
        title: "Sort by popularity"
    },
    {
        title: "Sort by price: low to high"
    },
    {
        title: "Sort by price: high to low"
    }
]
