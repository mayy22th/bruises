export const sortReviewData = [
    {
        title: "Sort by date: newest to oldest",
    },
    {
        title: "Sort by date: oldest to newest",
    },
];
