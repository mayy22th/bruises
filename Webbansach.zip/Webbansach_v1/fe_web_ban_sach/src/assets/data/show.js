export const showData = [
    {
        title: "Show 5",
    },
    {
        title: "Show 15",
    },
    {
        title: "Show 20",
    },
    {
        title: "Show 25",
    },
];
