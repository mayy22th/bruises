export const booksData = [
    {
        image: "book1",
        name: "Book 1",
        author: "Author 1",
        discount_price: "50.00",
        final_price: "60.00"
    },
    {
        image: "book2",
        name: "Book 2",
        author: "Author 2",
        discount_price: "50.00",
        final_price: "60.00"
    },
    {
        image: "book3",
        name: "Book 3",
        author: "Author 3",
        discount_price: "50.00",
        final_price: "60.00"
    },
    {
        image: "book4",
        name: "Book 4",
        author: "Author 4",
        discount_price: "50.00",
        final_price: "60.00"
    },
    {
        image: "book5",
        name: "Book 5",
        author: "Author 5",
        discount_price: "50.00",
        final_price: "60.00"
    },
    {
        image: "book6",
        name: "Book 6",
        author: "Author 6",
        discount_price: "50.00",
        final_price: "60.00"
    },
    {
        image: "book7",
        name: "Book 7",
        author: "Author 7",
        discount_price: "50.00",
        final_price: "60.00"
    },
    {
        image: "book8",
        name: "Book 8",
        author: "Author 8",
        discount_price: "50.00",
        final_price: "60.00"
    }
]
