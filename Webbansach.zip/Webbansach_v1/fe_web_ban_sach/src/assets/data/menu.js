export const menuData = [
    {
        title: "Home",
        link: "/"
    },
    {
        title: "Shop",
        link: "/shop"
    },
    {
        title: "About",
        link: "/about"
    },
    {
        title: "Cart",
        link: "/cart"
    }
]
