export const filter_SET_DATA_FILTER = "filter_SET_DATA_FILTER";
export const filter_SET_CURRENT_CATEGORIES = "filter_SET_CURRENT_CATEGORIES";
export const filter_SET_CURRENT_AUTHORS = "filter_SET_CURRENT_CATEGORIES";
export const filter_SET_CURRENT_RATING_STARS =
    "filter_SET_CURRENT_RATING_STARS";
export const filter_SET_RESET = "filter_SET_RESET";
