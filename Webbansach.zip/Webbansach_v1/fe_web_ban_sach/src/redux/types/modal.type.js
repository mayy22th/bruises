export const modal_OPEN_MODAL = "modal_OPEN_MODAL";
export const modal_CLOSE_MODAL = "modal_CLOSE_MODAL";
export const modal_HEADING_TITLE_MODAL = "modal_HEADING_TITLE_MODAL";
export const modal_CONTENT_BUTTON = "modal_CONTENT_BUTTON";
