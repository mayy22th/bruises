export const app_SET_WIDTH = "app_SET_WIDTH";
export const app_SET_LOGIN = "app_SET_LOGIN";
export const app_SET_USER = "app_SET_USER";
export const app_SET_SUM_CART_QUANTITY = "app_SET_SUM_CART_QUANTITY";
