export const product_SET_DETAIL_BOOK = "product_SET_DETAIL_BOOK";
export const product_SET_QUANTITY_BOOK = "product_SET_QUANTITY_BOOK";
export const product_SET_DISCOUNT_PRICE_BOOK =
    "product_SET_DISCOUNT_PRICE_BOOK";
export const product_SET_MAIN_PRICE_BOOK = "product_SET_MAIN_PRICE_BOOK";
export const product_SET_FIRST_LOADING_REVIEW =
    "product_SET_FIRST_LOADING_REVIEW";
export const product_SET_SECOND_LOADING_REVIEW =
    "product_SET_SECOND_LOADING_REVIEW";
export const product_SET_REVIEW_DATA = "product_SET_REVIEW_DATA";
export const product_AVERAGE_REVIEW = "product_AVERAGE_REVIEW";
export const product_TOTAL_REVIEW = "product_TOTAL_REVIEW";
export const product_COUNT_RATING_STAR = "product_COUNT_RATING_STAR";
export const product_FROM_REVIEW = "product_FROM_REVIEW";
export const product_TO_REVIEW = "product_TO_REVIEW";
export const product_TOTAL_PAGE_REVIEW = "product_TOTAL_PAGE_REVIEW";
export const product_CURRENT_PAGE_REVIEW = "product_CURRENT_PAGE_REVIEW";
export const product_CURRENT_FILTER_STAR = "product_CURRENT_FILTER_STAR";
export const product_SORT_REVIEW = "product_SORT_REVIEW";
export const product_SET_PER_PAGE = "product_SET_PER_PAGE";
export const product_SET_RESET = "product_SET_RESET";
export const product_SET_PRICE_BOOK = "product_SET_PRICE_BOOK";
