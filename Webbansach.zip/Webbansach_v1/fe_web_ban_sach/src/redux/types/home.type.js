export const home_SET_TOP_TEN_ON_SALE_BOOKS = "home_SET_TOP_TEN_ON_SALE_BOOKS";
export const home_SET_TAG_FEATURED_BOOKS = "home_SET_TAG_FEATURED_BOOKS";
export const home_SET_IS_RECOMMENDED = "home_SET_IS_RECOMMENDED";
export const home_SET_FIRST_LOADING = "home_SET_FIRST_LOADING";
export const home_RESET = "home_RESET";
